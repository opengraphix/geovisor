The samples can be browsed by opening the examples folder in a web browser.

The samples home page (samples.html) along with some of the individual sample pages use XHR to load data. 
Those samples will need to be on a webserver (http://) to run since XHR can't access the local file system.